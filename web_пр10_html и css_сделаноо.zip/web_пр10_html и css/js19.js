// 1. Анимация наверху страницы при загрузке
window.addEventListener("DOMContentLoaded", () => {
    // Появление верхней панели
    const header = document.getElementById("header-anim");
    if (header) {
        header.classList.add("show");
    }

    // Появление центрального контента (эффект всплытия)
    const mainContent = document.querySelector(".main-content");
    if (mainContent) {
        mainContent.classList.add("visible");
    }
});

// 2. Анимация появления элементов при прокрутке (Scroll Animation)
window.addEventListener("scroll", () => {
    const animBox = document.querySelector(".scroll-box");
    
    if (animBox) {
        const boxPosition = animBox.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.2; // Точка срабатывания

        if (boxPosition < screenPosition) {
            animBox.classList.add("visible");
        }
    }
});